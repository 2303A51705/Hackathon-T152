import java.util.Scanner;

class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Soil pH (e.g., 6.5): ");
        double soilPH = sc.nextDouble();
        
        
        System.out.print("Enter Nitrogen level (low/medium/high): ");
        String nitrogen = sc.next().toLowerCase();
        
        System.out.print("Enter Phosphorus level (low/medium/high): ");
        String phosphorus = sc.next().toLowerCase();
        
        System.out.print("Enter Potassium level (low/medium/high): ");
        String potassium = sc.next().toLowerCase();
        
        System.out.print("Enter Crop Type (e.g., Wheat, Rice, Maize): ");
        String cropType = sc.next();
        
        System.out.print("Enter Rainfall Condition (low/medium/high): ");
        String rainfall = sc.next().toLowerCase();
        
        
        String fertilizerRecommendation = getFertilizerRecommendation(soilPH, nitrogen, phosphorus, potassium, cropType, rainfall);
        
        
        System.out.println("\nOptimal Fertilizer Recommendation:");
        System.out.println(fertilizerRecommendation);
        
        sc.close();
    }

    
    public static String getFertilizerRecommendation(double soilPH, String nitrogen, String phosphorus, String potassium, String cropType, String rainfall) {
        String recommendation = "";
        
        if (soilPH < 5.5) {
            recommendation += "- Apply Lime to increase soil pH.\n";
        } else if (soilPH > 7.5) {
            recommendation += "- Apply Sulfur to decrease soil pH.\n";
        }

        
        if (nitrogen.equals("low")) {
            recommendation += "- Use Urea or Ammonium Sulfate (High Nitrogen Fertilizer).\n";
        } else if (nitrogen.equals("high")) {
            recommendation += "- Reduce Nitrogen application to prevent soil degradation.\n";
        }


        if (phosphorus.equals("low")) {
            recommendation += "- Use Super Phosphate or DAP (Phosphorus-rich Fertilizer).\n";
        }

        
        if (potassium.equals("low")) {
            recommendation += "- Use Potassium Sulfate or Muriate of Potash.\n";
        }

    
        switch (cropType.toLowerCase()) {
            case "wheat":
                recommendation += "- Apply balanced NPK (Nitrogen-Phosphorus-Potassium) fertilizer in 2 doses.\n";
                break;
            case "rice":
                recommendation += "- Use DAP and Urea before flooding fields.\n";
                break;
            case "maize":
                recommendation += "- High Nitrogen required; use Ammonium Nitrate.\n";
                break;
            default:
                recommendation += "- Use a general-purpose balanced fertilizer (NPK 10-10-10).\n";
        }

       
        if (rainfall.equals("low")) {
            recommendation += "- Use slow-release fertilizers to prevent leaching.\n";
        } else if (rainfall.equals("high")) {
            recommendation += "- Avoid excessive Nitrogen use as it can wash away easily.\n";
        }

        return recommendation;
    }
}
